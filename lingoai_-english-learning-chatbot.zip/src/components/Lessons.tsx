import React, { useState } from 'react';
import { BookOpen, ChevronRight, CheckCircle2, Lock, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getLessonContent } from '../services/gemini';
import ReactMarkdown from 'react-markdown';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { toast } from 'sonner';

const LESSON_TOPICS = [
  { id: '1', title: 'Basic Greetings', category: 'Vocabulary', difficulty: 'Beginner', xp: 50 },
  { id: '2', title: 'Present Continuous', category: 'Grammar', difficulty: 'Beginner', xp: 75 },
  { id: '3', title: 'Common Idioms', category: 'Idioms', difficulty: 'Intermediate', xp: 100 },
  { id: '4', title: 'Business English', category: 'Vocabulary', difficulty: 'Advanced', xp: 150 },
  { id: '5', title: 'Conditional Sentences', category: 'Grammar', difficulty: 'Intermediate', xp: 120 },
];

export function Lessons({ profile }: { profile: any }) {
  const [selectedLesson, setSelectedLesson] = useState<any>(null);
  const [lessonContent, setLessonContent] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const startLesson = async (lesson: any) => {
    if (lesson.difficulty === 'Advanced' && !profile.isPremium) {
      toast.error("Advanced lessons require a Premium subscription!");
      return;
    }

    setSelectedLesson(lesson);
    setLoading(true);
    try {
      const content = await getLessonContent(lesson.title, profile.level);
      setLessonContent(content);
    } catch (error) {
      toast.error("Failed to load lesson content.");
    } finally {
      setLoading(false);
    }
  };

  const completeLesson = async () => {
    try {
      const userDoc = doc(db, 'users', profile.uid);
      await updateDoc(userDoc, {
        xp: (profile.xp || 0) + selectedLesson.xp,
        badges: [...(profile.badges || []), `${selectedLesson.title} Master`]
      });
      toast.success(`Lesson complete! +${selectedLesson.xp} XP`);
      setSelectedLesson(null);
      setLessonContent(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'users');
    }
  };

  return (
    <div className="space-y-6">
      <AnimatePresence mode="wait">
        {!selectedLesson ? (
          <motion.div 
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-4"
          >
            <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] mb-6">Learning Path</h2>
            {LESSON_TOPICS.map((lesson) => (
              <LessonCard 
                key={lesson.id} 
                lesson={lesson} 
                isLocked={lesson.difficulty === 'Advanced' && !profile.isPremium}
                onStart={() => startLesson(lesson)} 
              />
            ))}
          </motion.div>
        ) : (
          <motion.div 
            key="content"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-[32px] p-8 shadow-sm border border-[#5A5A40]/10"
          >
            <div className="flex items-center justify-between mb-8">
              <button onClick={() => setSelectedLesson(null)} className="text-[#5A5A40] font-medium flex items-center gap-1">
                <ChevronRight className="rotate-180 w-4 h-4" />
                Back to Lessons
              </button>
              <div className="bg-[#F5F5F0] px-3 py-1 rounded-full text-xs font-bold text-[#5A5A40]">
                {selectedLesson.category} • {selectedLesson.xp} XP
              </div>
            </div>

            {loading ? (
              <div className="py-20 flex flex-col items-center gap-4">
                <div className="w-10 h-10 border-4 border-[#5A5A40] border-t-transparent rounded-full animate-spin" />
                <p className="text-[#5A5A40] italic">Generating your personalized lesson...</p>
              </div>
            ) : (
              <div className="space-y-8">
                <div className="prose prose-slate max-w-none">
                  <ReactMarkdown>{lessonContent || ''}</ReactMarkdown>
                </div>
                <button 
                  onClick={completeLesson}
                  className="w-full bg-[#5A5A40] text-white py-4 rounded-full font-bold text-lg hover:bg-[#4A4A30] transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-6 h-6" />
                  Complete Lesson
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function LessonCard({ lesson, isLocked, onStart }: { lesson: any, isLocked: boolean, onStart: () => void }) {
  return (
    <button 
      onClick={onStart}
      className={`w-full bg-white p-6 rounded-[24px] border border-[#5A5A40]/10 shadow-sm flex items-center gap-4 hover:border-[#5A5A40]/30 transition-all text-left ${isLocked ? 'opacity-75' : ''}`}
    >
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isLocked ? 'bg-gray-100' : 'bg-[#F5F5F0]'}`}>
        {isLocked ? <Lock className="w-6 h-6 text-gray-400" /> : <BookOpen className="w-6 h-6 text-[#5A5A40]" />}
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <h4 className="font-serif font-bold text-[#1A1A1A]">{lesson.title}</h4>
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
            lesson.difficulty === 'Beginner' ? 'bg-green-100 text-green-700' :
            lesson.difficulty === 'Intermediate' ? 'bg-blue-100 text-blue-700' :
            'bg-purple-100 text-purple-700'
          }`}>
            {lesson.difficulty}
          </span>
        </div>
        <p className="text-xs text-[#5A5A40] opacity-70">{lesson.category} • {lesson.xp} XP Reward</p>
      </div>
      <ChevronRight className="text-[#A0A080] w-5 h-5" />
    </button>
  );
}
