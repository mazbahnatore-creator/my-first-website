import React, { useState } from 'react';
import { Crown, Check, X, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { toast } from 'sonner';

export function PaymentModal({ isOpen, onClose, profile }: { isOpen: boolean, onClose: () => void, profile: any }) {
  const [loading, setLoading] = useState(false);

  const handleUpgrade = async () => {
    setLoading(true);
    try {
      // Simulate Stripe payment success for demo purposes
      // In a real app, you'd call the /api/create-payment-intent and use Stripe Elements
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const userDoc = doc(db, 'users', profile.uid);
      await updateDoc(userDoc, {
        isPremium: true,
        badges: [...(profile.badges || []), 'Premium Member']
      });
      
      toast.success("Welcome to LingoAI Premium!");
      onClose();
    } catch (error) {
      toast.error("Payment failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-[32px] max-w-md w-full p-8 shadow-2xl relative"
      >
        <button onClick={onClose} className="absolute top-6 right-6 text-[#A0A080] hover:text-[#5A5A40]">
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Crown className="text-yellow-600 w-8 h-8" />
          </div>
          <h2 className="text-3xl font-serif font-bold text-[#1A1A1A]">LingoAI Premium</h2>
          <p className="text-[#5A5A40] italic">Take your fluency to the next level.</p>
        </div>

        <div className="space-y-4 mb-8">
          <FeatureItem text="Unlimited AI Chat sessions" />
          <FeatureItem text="Advanced lessons & quizzes" />
          <FeatureItem text="Voice correction & feedback" />
          <FeatureItem text="Detailed progress analytics" />
          <FeatureItem text="Exclusive Premium badges" />
        </div>

        <div className="bg-[#F5F5F0] p-6 rounded-2xl mb-8 text-center">
          <div className="text-sm text-[#5A5A40] font-bold uppercase tracking-wider mb-1">Monthly Plan</div>
          <div className="text-4xl font-serif font-bold text-[#1A1A1A]">$9.99<span className="text-lg font-normal opacity-60">/mo</span></div>
        </div>

        <button 
          onClick={handleUpgrade}
          disabled={loading}
          className="w-full bg-[#5A5A40] text-white py-4 rounded-full font-bold text-lg hover:bg-[#4A4A30] transition-colors flex items-center justify-center gap-2"
        >
          {loading ? (
            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <ShieldCheck className="w-6 h-6" />
              Upgrade Now
            </>
          )}
        </button>
        <p className="text-[10px] text-center text-[#A0A080] mt-4">
          Secure payment powered by Stripe. Cancel anytime.
        </p>
      </motion.div>
    </div>
  );
}

function FeatureItem({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
        <Check className="text-green-600 w-3 h-3" />
      </div>
      <span className="text-[#1A1A1A] font-medium">{text}</span>
    </div>
  );
}
