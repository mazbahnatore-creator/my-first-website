import React, { useState, useEffect, useRef } from 'react';
import { Send, Sparkles, AlertCircle, CheckCircle2 } from 'lucide-react';
import { getChatResponse } from '../services/gemini';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { doc, updateDoc, arrayUnion, onSnapshot, setDoc } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';

export function Chat({ profile }: { profile: any }) {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const chatId = `chat_${profile.uid}`;
    const chatDoc = doc(db, 'chats', chatId);
    
    const unsubscribe = onSnapshot(chatDoc, (snap) => {
      if (snap.exists()) {
        setMessages(snap.data().messages || []);
      } else {
        const initialMessage = {
          role: 'assistant',
          content: `Hello ${profile.displayName}! I'm your AI English tutor. How can I help you practice today? We can role-play a scenario or just chat!`,
          timestamp: new Date().toISOString()
        };
        setDoc(chatDoc, {
          uid: profile.uid,
          messages: [initialMessage]
        });
      }
    });

    return () => unsubscribe();
  }, [profile.uid]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = {
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    };

    setInput('');
    setLoading(true);

    try {
      const chatId = `chat_${profile.uid}`;
      const chatDoc = doc(db, 'chats', chatId);
      
      // Optimistic update
      setMessages(prev => [...prev, userMessage]);

      const history = messages.slice(-10);
      const aiResponse = await getChatResponse(input, history, profile.level);

      const assistantMessage = {
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date().toISOString()
      };

      await updateDoc(chatDoc, {
        messages: arrayUnion(userMessage, assistantMessage)
      });

      // Award XP for chatting
      const userDoc = doc(db, 'users', profile.uid);
      await updateDoc(userDoc, {
        xp: (profile.xp || 0) + 5
      });

    } catch (error) {
      console.error("Chat error", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-12rem)] bg-white rounded-[32px] shadow-sm border border-[#5A5A40]/10 overflow-hidden">
      {/* Chat Header */}
      <div className="p-4 border-b border-[#5A5A40]/10 bg-[#F5F5F0] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="text-[#5A5A40] w-5 h-5" />
          <span className="font-serif font-bold text-[#1A1A1A]">AI Tutor</span>
        </div>
        <div className="text-xs text-[#5A5A40] font-medium bg-white px-2 py-1 rounded-full border border-[#5A5A40]/20">
          {profile.level} Mode
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[85%] p-4 rounded-2xl ${
              msg.role === 'user' 
                ? 'bg-[#5A5A40] text-white rounded-tr-none' 
                : 'bg-[#F5F5F0] text-[#1A1A1A] rounded-tl-none border border-[#5A5A40]/10'
            }`}>
              <div className="prose prose-sm max-w-none">
                <ReactMarkdown>{msg.content}</ReactMarkdown>
              </div>
              <div className={`text-[10px] mt-2 opacity-50 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </motion.div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-[#F5F5F0] p-4 rounded-2xl rounded-tl-none border border-[#5A5A40]/10">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-[#5A5A40] rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-[#5A5A40] rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-2 h-2 bg-[#5A5A40] rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-[#F5F5F0] border-t border-[#5A5A40]/10">
        <div className="flex gap-2">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your message..."
            className="flex-1 bg-white border border-[#5A5A40]/20 rounded-full px-6 py-3 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50"
          />
          <button 
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="bg-[#5A5A40] text-white p-3 rounded-full hover:bg-[#4A4A30] transition-colors disabled:opacity-50"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
