import React from 'react';
import { Trophy, Star, Flame, Award, Crown } from 'lucide-react';
import { motion } from 'motion/react';

export function Dashboard({ profile, onUpgrade }: { profile: any, onUpgrade: () => void }) {
  return (
    <div className="space-y-6">
      {/* Profile Card */}
      <div className="bg-white rounded-[32px] p-8 shadow-sm border border-[#5A5A40]/10">
        <div className="flex items-center gap-6 mb-8">
          <div className="w-20 h-20 bg-[#F5F5F0] rounded-full flex items-center justify-center text-3xl">
            {profile?.displayName?.[0] || 'U'}
          </div>
          <div>
            <h2 className="text-2xl font-serif font-bold text-[#1A1A1A]">{profile?.displayName}</h2>
            <p className="text-[#5A5A40] italic">{profile?.level} Learner</p>
          </div>
          {profile?.isPremium && (
            <div className="ml-auto bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full flex items-center gap-1 text-sm font-bold">
              <Crown className="w-4 h-4" />
              Premium
            </div>
          )}
        </div>

        <div className="grid grid-cols-3 gap-4">
          <StatCard icon={<Flame className="text-orange-500" />} value={profile?.streak || 0} label="Day Streak" />
          <StatCard icon={<Trophy className="text-yellow-500" />} value={profile?.xp || 0} label="Total XP" />
          <StatCard icon={<Star className="text-blue-500" />} value={profile?.badges?.length || 0} label="Badges" />
        </div>
      </div>

      {/* Badges Section */}
      <div className="bg-white rounded-[32px] p-8 shadow-sm border border-[#5A5A40]/10">
        <h3 className="text-xl font-serif font-bold text-[#1A1A1A] mb-6 flex items-center gap-2">
          <Award className="text-[#5A5A40]" />
          Your Achievements
        </h3>
        {profile?.badges?.length > 0 ? (
          <div className="grid grid-cols-4 gap-4">
            {profile.badges.map((badge: string, i: number) => (
              <div key={i} className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 bg-[#F5F5F0] rounded-full flex items-center justify-center">
                  🏅
                </div>
                <span className="text-xs text-center font-medium">{badge}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-[#A0A080] italic text-center py-4">Complete lessons to earn badges!</p>
        )}
      </div>

      {/* Upgrade Call to Action */}
      {!profile?.isPremium && (
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-[#5A5A40] rounded-[32px] p-8 text-white shadow-lg relative overflow-hidden"
        >
          <div className="relative z-10">
            <h3 className="text-2xl font-serif font-bold mb-2">Unlock Premium</h3>
            <p className="opacity-90 mb-6">Get unlimited AI chat, voice corrections, and advanced lessons.</p>
            <button 
              onClick={onUpgrade}
              className="bg-white text-[#5A5A40] px-6 py-2 rounded-full font-bold hover:bg-opacity-90 transition-opacity"
            >
              Upgrade Now
            </button>
          </div>
          <Crown className="absolute -right-4 -bottom-4 w-32 h-32 opacity-10 rotate-12" />
        </motion.div>
      )}
    </div>
  );
}

function StatCard({ icon, value, label }: { icon: React.ReactNode, value: number | string, label: string }) {
  return (
    <div className="bg-[#F5F5F0] p-4 rounded-2xl text-center">
      <div className="flex justify-center mb-2">{icon}</div>
      <div className="text-xl font-bold text-[#1A1A1A]">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-[#5A5A40] font-bold">{label}</div>
    </div>
  );
}
