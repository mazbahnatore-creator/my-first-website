import React, { useState, useEffect } from 'react';
import { auth, googleProvider, db, handleFirestoreError, OperationType } from './firebase';
import { signInWithPopup, onAuthStateChanged, User, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { Dashboard } from './components/Dashboard';
import { Chat } from './components/Chat';
import { Lessons } from './components/Lessons';
import { PaymentModal } from './components/PaymentModal';
import { Toaster } from 'sonner';
import { BookOpen, MessageSquare, Trophy, User as UserIcon, LogOut, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'lessons' | 'chat'>('dashboard');
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const userDoc = doc(db, 'users', u.uid);
        onSnapshot(userDoc, (docSnap) => {
          if (docSnap.exists()) {
            setProfile(docSnap.data());
          } else {
            // Initialize profile
            const newProfile = {
              uid: u.uid,
              displayName: u.displayName,
              email: u.email,
              level: 'Beginner',
              xp: 0,
              streak: 0,
              lastActive: new Date().toISOString(),
              isPremium: false,
              badges: []
            };
            setDoc(userDoc, newProfile).catch(e => handleFirestoreError(e, OperationType.CREATE, 'users'));
            setProfile(newProfile);
          }
        }, (error) => handleFirestoreError(error, OperationType.GET, 'users'));
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleLogout = () => signOut(auth);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-[#5A5A40] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex flex-col items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-[32px] p-8 shadow-xl text-center"
        >
          <div className="w-20 h-20 bg-[#5A5A40] rounded-full flex items-center justify-center mx-auto mb-6">
            <Zap className="text-white w-10 h-10" />
          </div>
          <h1 className="text-4xl font-serif font-bold text-[#1A1A1A] mb-4">LingoAI</h1>
          <p className="text-[#5A5A40] mb-8 font-serif italic text-lg">
            Master English through AI-powered conversations and gamified lessons.
          </p>
          <button 
            onClick={handleLogin}
            className="w-full bg-[#5A5A40] text-white py-4 rounded-full font-semibold text-lg hover:bg-[#4A4A30] transition-colors flex items-center justify-center gap-3"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="Google" />
            Continue with Google
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] pb-24">
      <Toaster position="top-center" />
      
      {/* Header */}
      <header className="bg-white border-b border-[#5A5A40]/10 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="text-[#5A5A40] w-6 h-6" />
            <span className="font-serif font-bold text-xl text-[#1A1A1A]">LingoAI</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 bg-[#F5F5F0] px-3 py-1 rounded-full">
              <Trophy className="w-4 h-4 text-yellow-600" />
              <span className="text-sm font-bold">{profile?.xp || 0} XP</span>
            </div>
            <button onClick={handleLogout} className="text-[#5A5A40] hover:text-red-600 transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div key="dashboard" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
              <Dashboard profile={profile} onUpgrade={() => setIsPaymentOpen(true)} />
            </motion.div>
          )}
          {activeTab === 'lessons' && (
            <motion.div key="lessons" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
              <Lessons profile={profile} />
            </motion.div>
          )}
          {activeTab === 'chat' && (
            <motion.div key="chat" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
              <Chat profile={profile} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#5A5A40]/10 px-4 py-3">
        <div className="max-w-md mx-auto flex justify-around items-center">
          <NavButton 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
            icon={<UserIcon />} 
            label="Profile" 
          />
          <NavButton 
            active={activeTab === 'lessons'} 
            onClick={() => setActiveTab('lessons')} 
            icon={<BookOpen />} 
            label="Learn" 
          />
          <NavButton 
            active={activeTab === 'chat'} 
            onClick={() => setActiveTab('chat')} 
            icon={<MessageSquare />} 
            label="Chat" 
          />
        </div>
      </nav>
      <PaymentModal isOpen={isPaymentOpen} onClose={() => setIsPaymentOpen(false)} profile={profile} />
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactElement, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-[#5A5A40]' : 'text-[#A0A080]'}`}
    >
      {React.cloneElement(icon, { 
        className: `w-6 h-6 ${active ? 'text-[#5A5A40]' : 'text-[#A0A080]'}` 
      } as any)}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}
