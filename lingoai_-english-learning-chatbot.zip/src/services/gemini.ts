import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getChatResponse(message: string, history: any[], level: string, scenario?: string) {
  const systemInstruction = `
    You are an AI-powered English Learning Chatbot. 
    User Level: ${level}
    Scenario: ${scenario || "General Conversation"}
    
    Guidelines:
    1. Provide instant corrections for grammar, vocabulary, and pronunciation (text-based).
    2. Explain corrections clearly in 1-2 sentences.
    3. Keep the conversation engaging and motivating.
    4. Use language appropriate for a ${level} learner.
    5. If the user makes a mistake, show the corrected version and explain why.
    6. Encourage the user to keep practicing.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      { role: "user", parts: [{ text: systemInstruction }] },
      ...history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }]
      })),
      { role: "user", parts: [{ text: message }] }
    ],
  });

  return response.text;
}

export async function getLessonContent(topic: string, level: string) {
  const prompt = `Create a short English lesson for a ${level} learner on the topic: ${topic}. 
  Include:
  1. A brief explanation.
  2. 3-5 key vocabulary words or phrases with meanings.
  3. 2-3 practice exercises (multiple choice or fill-in-the-blank).
  Format the response as Markdown.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });

  return response.text;
}
